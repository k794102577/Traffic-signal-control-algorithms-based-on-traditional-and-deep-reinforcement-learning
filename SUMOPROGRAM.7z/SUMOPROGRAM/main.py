# -*- coding: utf-8 -*-
"""
Created on Fri Jan 10 09:18:32 2025

@author: DELL001
"""


import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque
import matplotlib.pyplot as plt
import os
import sys
import copy

import traci

path0 = r"C:\Users\kongyu\Desktop\SUMOPROGRAM\2025_DQN_signal_model_save" # 保存模型和图片的文件夹

class SumoEnv():
    def __init__(self):
        
        self.veh_len = 5 # 车长
        self.min_gap = 2.5 # 最小车间隔
        
        self.dt = 1.0 # 仿真步长
        self.end_time = 3600 - 3400 # 结束时的仿真时长
        self.phase = {0: 'rrrGGrrrrGGr',
                    1: 'rrrrrGrrrrrG',
                    2: 'GGrrrrGGrrrr',
                    3: 'rrGrrrrrGrrr',} # 手写信号相位与对应的信号状态
        self.phase_to_state = { value:key for key, value in self.phase.items() }
        self.phase_duration_dict = { key:0 for key, value in self.phase.items() } # 相位持续时间
        self.phase_duration_min = 5 # 最小相位持续时间
        self.phase_duration_max = 50 # 最大相位持续时间
        
        self.phase_lane = { 0:['E0_0', 'E2_0'],
                            1:['E0_1', 'E2_1'],
                            2:['E1_0', 'E3_0'],
                            3:['E1_1', 'E3_1'],} # 信号相位与对应的绿灯车道
        
        
        self.cell_len = 20 # 元胞长度，米
        self.reset() # 重置
    
    def reset(self):
        
        if 'SUMO_HOME' in os.environ:
            sys.path.append(os.path.join(os.environ['SUMO_HOME'], 'tools'))
            
        try:
            sumoBinary = r"C:\Program Files (x86)\Eclipse\Sumo\bin\sumo-gui" # sumo.exe的位置，这里不用加.exe -gui
            sumocfg_path = r"C:\Users\kongyu\Desktop\SUMOPROGRAM\DQN_signal.sumocfg" # sumocfg文件的位置，就是三个save文件之一
            sumocmd = [ sumoBinary, "-c", sumocfg_path, '--step-length', str(self.dt) ]
            traci.start( sumocmd ) # 打开接口
        except:
            traci.close()
            sumoBinary = r"C:\Program Files (x86)\Eclipse\Sumo\bin\sumo-gui" # sumo.exe的位置，这里不用加.exe -gui
            sumocfg_path = r"C:\Users\kongyu\Desktop\SUMOPROGRAM\DQN_signal.sumocfg" # sumocfg文件的位置，就是三个save文件之一
            sumocmd = [ sumoBinary, "-c", sumocfg_path, '--step-length', str(self.dt) ]
            traci.start( sumocmd ) # 打开接口
        
        # 初始的信号灯id，和当前仿真时长
        self.traffic_light_id = traci.trafficlight.getIDList()[0]
        print("self.traffic_light_id",self.traffic_light_id)
        self.simulation_time = traci.simulation.getTime()
        print("self.simulation_time",self.simulation_time)
        # 所有进口道长度
        self.approach_lane = ['E0_0', 'E0_1', 'E1_0', 'E1_1', 'E2_0', 'E2_1', 'E3_0', 'E3_1']
        self.lane_len = { ii: traci.lane.getLength(ii) for ii in self.approach_lane }
        print("self.lane_len",self.lane_len)
        self.approach_lane_max_len = max( self.lane_len.values() )
        self.info = {} # 仅仅是记录车辆的状态信息，画图用
        
        self.state = self.get_state()
        return self.state
    
    def get_state(self):
        space_state_init = np.zeros( (len(self.approach_lane), int(np.ceil(self.approach_lane_max_len/self.cell_len))) )
        speed_state_init = np.zeros( (len(self.approach_lane), int(np.ceil(self.approach_lane_max_len/self.cell_len))) )
        
        for vehid in traci.vehicle.getIDList():
            if traci.vehicle.getLaneID(vehid).split('_')[0] in ['E0', 'E1', 'E2', 'E3']:
                row = self.approach_lane.index( traci.vehicle.getLaneID(vehid) )
                col = int( traci.vehicle.getLanePosition(vehid) / self.cell_len )
                
                speed_state_init[row, col] = ( traci.vehicle.getSpeed(vehid) + speed_state_init[row, col] * space_state_init[row, col] ) / ( space_state_init[row, col] + 1 )
                space_state_init[row, col] += 1
                
        state = np.vstack( (space_state_init, speed_state_init) )
        return state
    
    def phase_change(self):
        """
        按照排队长度确定下一次相位，方法见公众号文章：https://mp.weixin.qq.com/s/kF2lhv02wpR30TgXAmb8Zg
        Parameters：
        - curr_phase: 当前相位
        - phase_duration: 相位持续时间
        - phase_duration_min: 相位持续时间下限
        - phase_duration_max: 相位持续时间上限
        - phase_lane_queue: 各个相位的排队长度
        - queue_max: 排队长度上限
    
        Returns：
        - next_phase: 下个相位的序号
        """
        # 0、参数
        curr_phase = self.phase_to_state[ traci.trafficlight.getRedYellowGreenState(self.traffic_light_id) ] # self.traffic_light_id = traci.trafficlight.getIDList()[0]
        self.phase_duration_dict[curr_phase] += self.dt
        for key, _ in self.phase_duration_dict.items():
            if key != curr_phase:
                self.phase_duration_dict[key] = 0 # 清零其他相位的持续时间
        phase_duration = self.phase_duration_dict[curr_phase]
        phase_lane_queue = { key:0 for key, value in self.phase.items() } # 初始化排队长度
        for key, _ in phase_lane_queue.items():
            phase_lane_queue[key] = max( [ traci.lane.getLastStepHaltingNumber( laneID ) for laneID in self.phase_lane[key] ] )
        queue_max = self.approach_lane_max_len
        
        # 1、约束
        con1 = phase_duration <= self.phase_duration_min  # 约束1：相位持续时间是否低于最小值
        con2 = phase_duration > self.phase_duration_min and phase_duration <= self.phase_duration_max  # 约束2：相位持续时间是否正常
        con3 = phase_duration > self.phase_duration_max  # 约束3：相位持续时间是否超出上限
    
        # 2、约束判断是否跳转相位
        if con1:
            next_phase = curr_phase
        elif con2:
            if max(phase_lane_queue.values()) > queue_max:
                # 这里如果最大排队仍然是当前相位，可以继续给绿灯，只要不超过最大限制就行
                next_phase = max(phase_lane_queue, key=phase_lane_queue.get)
            else:
                next_phase = curr_phase
        elif con3:
            sorted_keys = sorted(phase_lane_queue, key=phase_lane_queue.get, reverse=True)
            sorted_keys.remove(curr_phase)
            next_phase = sorted_keys[0]  # 下一个相位一定不是当前相位
        return next_phase
    
    def step(self, action:int):
        # 设计了四个与环境独立的动作
        self.simulation_time = traci.simulation.getTime() # 获取当前仿真时间
        # 保存相位持续时间

        # 保存车辆状态
        for vehid in traci.vehicle.getIDList():
            if traci.vehicle.getLaneID(vehid).split('_')[0] in ['E0', 'E1', 'E2', 'E3']:
                # 仅仅是记录车辆的状态信息，画图用
                ids = vehid
                x_in_lane = traci.vehicle.getLanePosition(ids)
                v_in_lane = traci.vehicle.getSpeed(ids)
                a_in_lane = traci.vehicle.getAcceleration(ids)
                edge_and_lane = traci.vehicle.getLaneID(ids)
                t = traci.simulation.getTime()
                info_list = [ t, x_in_lane, v_in_lane, a_in_lane, edge_and_lane ] # 新的一条
                
                if ids not in self.info.keys():
                    self.info[ids] = []
                self.info[ids].append( info_list ) # 更新进信息
        
        # 计算V0和V1
        V0_list = [ traci.vehicle.getSpeed(vehid) for vehid in traci.vehicle.getIDList() if traci.vehicle.getLaneID(vehid).split('_')[0] in ['E0', 'E1', 'E2', 'E3'] ]
        V0 = np.mean( V0_list if V0_list != [] else [0] )
        self.state = self.get_state()
        
        traci.trafficlight.setRedYellowGreenState( self.traffic_light_id, self.phase[action])  # 设置信号灯
        traci.simulationStep() # 更新
        V1_list = [ traci.vehicle.getSpeed(vehid) for vehid in traci.vehicle.getIDList() if traci.vehicle.getLaneID(vehid).split('_')[0] in ['E0', 'E1', 'E2', 'E3'] ]
        V1 = np.mean( V1_list if V1_list != [] else [0] )
        self.next_state = self.get_state()
        
        # 计算奖励值
        reward = 0.1 * (V1 - V0)
        # 游戏结束的标志：时间到达3550秒，或者至少有一条车道排队溢出
        max_queue_threshold = np.array( [ 0.8 * traci.lane.getLength(lane) / (self.veh_len + self.min_gap) for lane in self.approach_lane ] )
        veh_num_each_lane = self.next_state[0:len(self.approach_lane),:].sum(1)
        
        done = True if self.simulation_time >= self.end_time or any(veh_num_each_lane>max_queue_threshold) else False
        if any(veh_num_each_lane>max_queue_threshold):
            reward -= 10 # 追加
        # if self.simulation_time >= self.end_time:
        #     reward += 10 # 追加
        
        return self.next_state, reward, done

# 测试游戏环境是否可正确运行
# env = SumoEnv()
# done = False
# ans = []
# while not done:
#     # action = random.choice( list(env.phase.keys()) )
#     opt_action = env.phase_change(); action = opt_action
#     next_state, reward, done = env.step(action)
#     ans.append( [env.simulation_time, reward] )
#     # print(next_state)
# traci.close()
# plt.figure(88)
# plt.plot([i[0] for i in ans],[i[1] for i in ans] )

class DQN(nn.Module):
    # 有两点需要注意
    # 1、确保输入的二维矩阵state被正确展平为一维向量，以便输入到第一个全连接层。
    # 2、支持批量输入（即多个样本同时输入），因此需要处理形状为 (batch_size, input_dim[0], input_dim[1]) 的输入。
    def __init__(self, input_dim, output_dim):
        # 状态维度input_dim = (16, 15)，需要展平为16*15=240的一维矩阵
        # 输出维度output_dim = 6
        super(DQN, self).__init__()
        self.flatten = nn.Flatten() # 定义一个展平层，输入维度，例如 (16, 15) 展平为 (1, 240)
        self.fc1 = nn.Linear( input_dim[0] * input_dim[1], 128) # 240 -> 128 
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, output_dim)
    
    def forward(self, x):
        # 可以进行单个二维矩阵的输入，也可以是多个二维矩阵的输入时
        x = x.view(x.size(0), -1) if x.dim() >= 3 else x.unsqueeze(0).view(1,-1)  # 将输入矩阵展平 x.view(x.size(0), -1) 保持x的第一个维度不变，后续展平，比如将形状 (32, 16, 15) 重塑为 (32, 240)，可以处理批量的state输入（states）
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)
        

class DQNAgent():
    def __init__(self, input_dim, output_dim, lr=0.001, batch_size=64, gamma=0.99, epsilon_start=1, epsilon_end=0.1, epsilon_decay=500):
        # input_dim = (16, 15); output_dim = 4
        self.input_dim = input_dim # 状态，16*15 二维矩阵（8个车道上每20m间隔的元胞车辆的位置状态、速度状态，共16行，每行15个元胞）
        self.output_dim = output_dim # 动作，4个数字转成的二维矩阵
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') # 选择设备
        self.policy_net = DQN(input_dim, output_dim).to(self.device)
        self.target_net = DQN(input_dim, output_dim).to(self.device)
        self.target_net.load_state_dict(self.policy_net.state_dict()) # 复制加载三层网络的权重与偏置
        self.target_net.eval() # 值网络用于输出奖励，该网络每100次更新一次
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr) # list(policy_net.parameters())
        self.loss_fn = nn.MSELoss()
        
        
        self.memory = deque(maxlen=10000)
        self.gamma = gamma
        
        self.epsilon = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay
        self.epsilon_decay_rate = (epsilon_start - epsilon_end) / epsilon_decay
        
        self.action_set = [0, 1, 2, 3]
        
        
    def remember(self, state, action, reward, next_state, done):
        self.memory.append( (state, action, reward, next_state, done) )
    
    def act(self, state, opt_action=None):
        # 依概率，随机选择动作，或者取policy_net中的最大Q值对应动作
        if random.random() < self.epsilon: # epsilon的值会从1逐渐衰减到0.1，此过程为500
            if opt_action==None:
                return random.choice(range(self.output_dim))
            if opt_action in self.action_set:
                # 随机或者选择“启发式求出的最优”
                return opt_action if random.random() > 0.05 else random.choice(range(self.output_dim))
            
        state = torch.FloatTensor(state).to(self.device) # 二维矩阵，再增加一个维度 state = state.squeeze(0)
        with torch.no_grad(): # 会暂时禁用梯度计算，然后执行 action = ...，执行完with代码块后梯度计算会自动恢复
            action = self.policy_net(state).argmax().item() # .item()把tensor(3)变为3，将包含单个元素的张量转换为其对应的Python标量类型。
        # policy_net(state) 与 policy_net.forward(state)的关系
        # 在 PyTorch 中，nn.Module 类（所有神经网络模块的基类）实现了 __call__ 方法。
        # 当您调用 policy_net(state) 时，实际上是调用了 policy_net.__call__(state)。
        # nn.Module 的 __call__ 方法内部会调用 self.forward(state)，并处理一些额外的逻辑。
        return action
        
    def replay(self):
        # 经验回放（Experience Replay）
        # 经验回放 的核心思想是将这些经验存储在一个 经验池（memory buffer） 中，然后在训练过程中 随机抽取 一批样本进行学习
        # 优点：打破样本之间的相关性，提高样本利用率，减少对内存的需求
        if len(self.memory) < self.batch_size:
            return 
        batch = random.sample(self.memory, self.batch_size) # 随机抽取batch_size个样本。random.sample([1, 2, 3, 4, 5], 3) 输出: [4, 1, 5]
        states, actions, rewards, next_states, dones = zip(*batch) # 相当于batch是一个5列的表格，每一列取出后表示为states, actions, rewards, next_states, dones
        states = torch.FloatTensor(states).to(self.device) # 多个二维矩阵，float
        actions = torch.tensor(actions).to(self.device) # 多个一维矩阵，int
        rewards = torch.tensor(rewards, dtype=torch.float32).to(self.device) # 多个单数字，float。
        next_states = torch.FloatTensor(next_states).to(self.device) # 多个二维矩阵
        dones = torch.tensor(dones, dtype=torch.uint8).to(self.device) # 多个布尔值
        
        q_values = self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        next_q_values = self.target_net(next_states).max(1)[0]
        
        
        # 解释：self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        # policy_net(states)处理多个state，并获得每个state的全部动作的Q值，此时只需要选择每个状态下最大的Q值，例如
        # policy_net(states) = tensor([[ 0.0627,  0.0367,  0.0729, -0.0217],
        #        [ 0.0627,  0.0367,  0.0729, -0.0217],
        #        [ 0.0627,  0.0367,  0.0729, -0.0217]], grad_fn=<AddmmBackward0>)
        # 输出的是三个状态下四个动作的Q值，应找出每个状态下的特定动作的Q值，于是gather的dim应当取1，对行进行操作
        # actions = torch.tensor([0, 1, 1])，通过actions.unsqueeze(1)将临时改为tensor([[0],  [1],  [1]])
        # 那么gather的index应当取tensor([[0],  [1],  [1]])，policy_net(states)的每一行对应actions的每一行
        # 于是，第0行取出policy_net(states)的0行第0个元素，第1行取出policy_net(states)的1行第1个元素，第2行取出policy_net(states)的2行第1个元素
        # 取出后的结果为 tensor([[0.0627],  [0.0367], [0.0367]], grad_fn=<GatherBackward0>)
        # .squeeze(1)后变为tensor([0.0627, 0.0367, 0.0367], grad_fn=<SqueezeBackward1>)
        
        # 解释：self.target_net(next_states).max(1)[1]
        # target_net(next_states).max(1)输出torch.return_types.max( values=tensor([0.0333, 0.0333, 0.0333], grad_fn=<MaxBackward0>),  indices=tensor([3, 3, 3]))
        # max(1)指沿着行计算每个样本的最大Q值和对应的动作索引。
        # [0]取出最大Q值 tensor([0.0333, 0.0333, 0.0333], grad_fn=<MaxBackward0>) 
        # 如果是[1]，可以取出最大Q值的索引 tensor([3, 3, 3])
        
        target_q_values = rewards + (self.gamma * next_q_values * (1 - dones))
        
        loss = self.loss_fn(q_values, target_q_values)
        self.optimizer.zero_grad()
        loss.backward() # 计算损失函数相对于模型中所有可训练参数（requires_grad=True）的梯度，并将梯度存储在每个参数的 .grad 属性中
        self.optimizer.step() # optimizer.step() 会根据存储在每个参数 .grad 中的梯度来更新模型的参数。更新规则取决于所使用的优化算法（例如，Adam、SGD 等）。
        
    def update_target(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())
        
    def decay_epsilon(self):
        # 不断减少epsilon值，使得随机动作越来越少，依policy_net的最大Q值选择动作越来越多
        self.epsilon = max(self.epsilon_end, self.epsilon - self.epsilon_decay_rate)
        
# 训练 DQN Agent
def train_dqn(env, agent, num_episodes=100):
    # num_episodes训练过程中将执行的回合数，每个回合结束的标志就是done == True，也就是仿真时间达到3600附近，或者车道上车辆过多
    rewards_history = []
    
    for episode in range(num_episodes):
        state = env.reset() # numpy.array
        total_reward = 0
        
        done_global = False
        while not done_global:
            opt_action = env.phase_change()
            action = agent.act(state, opt_action=opt_action)
            next_state, reward, done = env.step(action)
            agent.remember( state, action, reward, next_state, done )
            state = next_state
            total_reward += reward
            done_global = done # 仿真时间达到3600附近，或者车道上车辆过多才停止这一轮
            
        # 每一轮结束后
        agent.update_target() # 把policy_net中的参数复制到target_net中
        agent.decay_epsilon() # 每一轮都要减少epsilon的值，由于epsilon_decay=500，所以需要500轮才能减少到0.1
        rewards_history.append(total_reward) # 统计游戏的总奖励值（仿真一个小时内的最大奖励）
        
        print(f"Episode {episode}, Total Reward: {total_reward}, Epsilon: {agent.epsilon}")
        
        if episode % 10 == 0:
            # 保存本循环的参数
            path = path0 + r"\trained_model_{}_{}.pth".format(episode, env.end_time)
            torch.save(agent.policy_net.state_dict(), path)
    
    # 训练结束后，绘制图
    plt.figure(10086)
    plt.rcParams['font.serif'] = ['Times New Roman']
    plt.rcParams['font.family'] = 'serif'
    fontsize = 12
    plt.rcParams['xtick.labelsize'] = fontsize  # 设置x轴刻度标签的字体大小为12
    plt.rcParams['ytick.labelsize'] = fontsize  # 设置y轴刻度标签的字体大小为12
    plt.plot(rewards_history)
    plt.xlabel('Episode', fontsize=fontsize+2, fontweight='bold')
    plt.ylabel('Total Reward', fontsize=fontsize+2, fontweight='bold')
    plt.tight_layout()
    plt.show()
    
    return agent.policy_net, rewards_history


# 测试训练好的模型
def test_model(env, model):
    state = env.reset() # numpy.array
    total_reward = 0
    all_action = [] # 记录所有的动作
    
    done_global = False
    while not done_global:
        state_tensor = torch.FloatTensor(state).to(next(model.parameters()).device)
        action = model(torch.FloatTensor(state_tensor)).argmax().item()
        # action = env.phase_change() # 此行代码会让启发式算法参与求解下一步最佳动作
        next_state, reward, done = env.step(action)
        # model.remember( state, action, reward, next_state, done ) # 相比于训练时不需要存
        state = next_state
        total_reward += reward
        done_global = done # 仿真时间达到3600附近，或者车道上车辆过多才停止这一轮
        
        all_action.append( [env.simulation_time, action] )
    print(f"Total Reward: {total_reward}")
    
    return env, all_action

# # 修改后的 test_model 函数
# def test_model(env, model):
#     state = env.reset()
#     total_reward = 0
#     all_action = []
    
#     try:
#         done_global = False
#         while not done_global:
#             try:
#                 state_tensor = torch.FloatTensor(state).to(next(model.parameters()).device)
#                 action = model(state_tensor).argmax().item()
#                 # action = env.phase_change() # 此行代码会让启发式算法参与求解下一步最佳动作
#                 next_state, reward, done = env.step(action)
#                 # model.remember( state, action, reward, next_state, done ) # 相比于训练时不需要存
#                 state = next_state
#                 total_reward += reward
#                 all_action.append( [env.simulation_time, action] )
#                 done_global = done
                
#                 # 添加定期通信检查
#                 if traci.simulation.getTime() % 50 == 0:
#                     traci.simulation.getDepartedNumber()  # 简单的保持连接的调用

#             except traci.TraCIException as e:
#                 print(f"TraCI error occurred: {str(e)}")
#                 break
#             except Exception as e:
#                 print(f"Unexpected error: {str(e)}")
#                 break
                
#     finally:
#         # 确保无论如何都关闭连接
#         try:
#             traci.close()
#         except traci.TraCIException:
#             pass  # 如果连接已经关闭则忽略
        
#     print(f"Total Reward: {total_reward}")
#     return env, all_action



def plot_info_lane(info, test_action, phase_lane, lane_len, dt, obj_lane ):
    
    info = copy.deepcopy( info )
    obj_lane_len = lane_len[obj_lane]
    
    # 画图设置
    # 设置英文字体为新罗马字体
    plt.rcParams['font.serif'] = ['Times New Roman']
    plt.rcParams['font.family'] = 'serif'
    fontsize = 12
    plt.rcParams['xtick.labelsize'] = fontsize  # 设置x轴刻度标签的字体大小为12
    plt.rcParams['ytick.labelsize'] = fontsize  # 设置y轴刻度标签的字体大小为12
    
    # 创建一个图形窗口，包含1行3列的子图
    fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(9, 6))
    info_view = { key: value for key, value in info.items() if len(value)>0 }
    
    # 找出绿灯时间
    green_t = []
    for t, action in test_action:
        green_lane = phase_lane[action] # 当前为绿灯的车道
        if obj_lane in green_lane:
            green_t.append(t)
    
    # 绘制红绿灯
    ax.plot([0, test_action[-1][0] + dt], [obj_lane_len, obj_lane_len], 'r', linewidth=4 )
    for t in green_t:
        ax.plot([t, t+dt], [obj_lane_len, obj_lane_len], 'g', linewidth=4 )   

    # 补轨迹
    for ii in list(info_view.keys()): # ii = list(info_view.keys())[1]
        # vehid = int(ii)
        xy = info_view[ii]
        x = [ iii[0] for iii in xy ]
        y = [ iii[1] for iii in xy ]
        lan = [ iii[4] for iii in xy ]
        # color = (random.random(), random.random(), random.random(), 1.0)
        # color_dict = { 'CAV':(7, 0, 255), 'HV': (0, 255, 0) }

        # 清洗
        the_connect_lane = [obj_lane] # ['E0_0', 'E2_0', 'E0_1', 'E2_1', 'E1_0', 'E3_0', 'E1_1', 'E3_1']
        x_choose = [ x[iii] for iii in range(len(x)) if lan[iii] in the_connect_lane ]
        y_choose = [ y[iii] for iii in range(len(x)) if lan[iii] in the_connect_lane ]
        lan_choose = [ lan[iii] for iii in range(len(x)) if lan[iii] in the_connect_lane ]
        
        iii = 0
        while iii < len(x_choose):
            iii_t = iii
            while iii < len(x_choose) and lan_choose[iii] == lan_choose[iii_t]:
                iii += 1
            ax.plot( x_choose[iii_t:iii+1], y_choose[iii_t:iii+1], color='grey', linestyle='-' )
            
    ax.axis([0, test_action[-1][0] + dt, 0, obj_lane_len + 20])
    ax.set_xlabel('Time (sec)', fontsize=fontsize+2, fontweight='bold')
    ax.set_ylabel('Distance (m)', fontsize=fontsize+2, fontweight='bold')
    ax.set_title('Lane: ' + obj_lane, fontsize=fontsize+2, fontweight='bold')
    plt.tight_layout()


# #%% 主程序
# if __name__ == "__main__":
#     env = SumoEnv()
#     input_dim = (16, 15)
#     output_dim = 4
#     num_episodes = 10
    
#     agent = DQNAgent(input_dim, output_dim)
#     # checkpoint = torch.load(path0 + r"\trained_model_200_3100.pth")

#     agent.policy_net.load_state_dict(torch.load(path0 + r"\trained_model_190_200.pth"))
#     agent.target_net.load_state_dict(torch.load(path0 + r"\trained_model_190_200.pth"))
#     # trained_model, rewards_history = train_dqn(env, agent, num_episodes)
    
#     # 保存参数
#     # path = path0 + r"\trained_model_{}_{}.pth".format( 300+num_episodes, env.end_time )
#     # torch.save(trained_model.state_dict(), path)
        
#     # 如果保存了训练参数，可以使用如下方式对参数进行加载，以直接测试模型
#     model = DQN(input_dim, output_dim)
#     model.load_state_dict(torch.load(path0 + r"\trained_model_190_200.pth"))
#     model.eval()
#     # test_model(env, model)
    
#     # env = SumoEnv() # env.end_time
#     test_env, test_action = test_model(env, model) # trained_model = agent.policy_net
    
#     info = test_env.info
#     phase_lane = test_env.phase_lane
#     lane_len = test_env.lane_len
#     dt = test_env.dt
    
#     for obj_lane in sum( list(phase_lane.values()), [] ):
#         plot_info_lane(info, test_action, phase_lane, lane_len, dt, obj_lane=obj_lane) # all_lane = sum( list(phase_lane.values()), [] )
#         path = path0 + r"\{}.png".format(obj_lane)
#         plt.savefig(path)
    
import time

# # 修改后的主程序
# if __name__ == "__main__":
#     try:
#         env = SumoEnv()
#         input_dim = (16, 15)
#         output_dim = 4
#         num_episodes = 200
        
#         agent = DQNAgent(input_dim, output_dim)
#         agent.policy_net.load_state_dict(torch.load(path0 + r"\trained_model_100_200.pth"))
#         agent.target_net.load_state_dict(torch.load(path0 + r"\trained_model_100_200.pth"))
        
            
#         # # 如果保存了训练参数，可以使用如下方式对参数进行加载，以直接测试模型
#         # model = DQN(input_dim, output_dim)
#         # model.load_state_dict(torch.load(path0 + r"\trained_model_100_200.pth"))
#         # model.eval()

#         #%% 四、仿真
#         # 1、参数设置
#         stop_time = 500 # 最大仿真时间
#         init_phase = 0 # 初始相位
#         phase_lane_queue = { key:0 for key,_ in env.phase_lane.items() } # 逐个相位下所有具有通行权的车道最大排队车辆数
#         queue_max = 10 # 排队车辆数上限

#         phase_duration = 0 # 相位持续时间
#         phase_duration_min = 10 # 最小相位持续时间
#         phase_duration_max = 60 # 最大相位持续时间
#         phase_shift = False # 相位切换时间

#         yellow_duration = 0 # 黄灯持续时间
#         yellow_duration_max = 3 # 最大黄灯持续时间
#         yellow_light = False # 黄灯期间

#         next_phase = 0 # 下一个相位
#         traci.trafficlight.setRedYellowGreenState( traci.trafficlight.getIDList()[0], env.phase[next_phase])  # 设置初始信号灯

#         ans = []  # 排队长度收集
   
#         while traci.simulation.getTime() < stop_time:
#             time.sleep(0.05) # 设置时延为 50ms
#             traci.simulationStep()
#             phase_duration += 1   # 更新相位持续时间
#             t = traci.simulation.getTime()  # 仿真时间更新
#             print( '当前仿真步长:{}'.format(t) )

#             for key, _ in phase_lane_queue.items():
#                 phase_lane_queue[key] = max( [ traci.lane.getLastStepHaltingNumber( laneID ) for laneID in  env.phase_lane[key] ] )

#         # 计算最佳相位
#             curr_phase = next_phase # 当前相位
#             next_phase = agent.act(state = torch.FloatTensor(env.state).to(agent.device))
#             # action = env.phase_change() # 此行代码会让启发式算法参与求解下一步最佳动作
#         ###计算各车道排队长度
#             queue_lengths = [traci.lane.getLastStepHaltingNumber(lane) for lane in env.approach_lane]
#             avg_queue = sum(queue_lengths)/len(queue_lengths) if len(queue_lengths) > 0 else 0

#             # 更新相位
#             if next_phase != curr_phase:
#                 # 先执行黄灯，或者说红灯间隔相位
#                 for _ in range( yellow_duration_max ):
#                     traci.trafficlight.setRedYellowGreenState(  traci.trafficlight.getIDList()[0],  'rrrrrrrrrrrr')  # 设置信号灯
#                     traci.simulationStep() # 直接向下更新三个
#                 # 再换成下一个相位
#                 phase_duration = 0 # 相位持续时间清零
#                 traci.trafficlight.setRedYellowGreenState(  traci.trafficlight.getIDList()[0], env.phase[next_phase] )  # 设置信号灯
            
#                 # 训练结束后，绘制图
#         plt.figure(10086)
#         plt.rcParams['font.serif'] = ['Times New Roman']
#         plt.rcParams['font.family'] = 'serif'
#         fontsize = 12
#         plt.rcParams['xtick.labelsize'] = fontsize  # 设置x轴刻度标签的字体大小为12
#         plt.rcParams['ytick.labelsize'] = fontsize  # 设置y轴刻度标签的字体大小为12
#         plt.plot(avg_queue)
#         plt.xlabel('Episode', fontsize=fontsize+2, fontweight='bold')
#         plt.ylabel('Total Reward', fontsize=fontsize+2, fontweight='bold')
#         plt.tight_layout()
#         plt.show()

#     #     # 使用上下文管理器确保连接关闭
#     #     try:
#     #         test_env, test_action = test_model(env, model)
            
#     #         info = test_env.info
#     #         phase_lane = test_env.phase_lane
#     #         lane_len = test_env.lane_len
#     #         dt = test_env.dt
            
#     #         for obj_lane in sum( list(phase_lane.values()), [] ):
#     #             plot_info_lane(info, test_action, phase_lane, lane_len, dt, obj_lane=obj_lane)
#     #             path = path0 + r"\{}.png".format(obj_lane)
#     #             plt.savefig(path)
                
                
#     # except Exception as e:
#     #     print(f"Main process error: {str(e)}")


#     finally:
#             traci.close()



if __name__ == "__main__":
    try:
        env = SumoEnv()
        input_dim = (16, 15)
        output_dim = 4
        num_episodes = 200
        
        agent = DQNAgent(input_dim, output_dim)
        agent.policy_net.load_state_dict(torch.load(path0 + r"\trained_model_500_200.pth"))
        agent.target_net.load_state_dict(torch.load(path0 + r"\trained_model_500_200.pth"))

        # 初始化数据记录
        queue_history = []  # 存储每个时间步的排队长度
        time_steps = []     # 存储时间步
        
        #%% 仿真参数设置
        stop_time = 3900
        next_phase = 0
        traci.trafficlight.setRedYellowGreenState(traci.trafficlight.getIDList()[0], env.phase[next_phase])

        # 创建实时图表
        plt.ion()  # 开启交互模式
        fig, ax = plt.subplots(figsize=(10, 6))
        line, = ax.plot([], [])
        ax.set_xlabel('Time Step (s)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Average Queue Length (veh)', fontsize=12, fontweight='bold')
        ax.set_title('Real-time Queue Length Monitoring', fontsize=14, fontweight='bold')
        ax.grid(True)

        while traci.simulation.getTime() < stop_time:
            time.sleep(0.05)
            traci.simulationStep()
            current_time = traci.simulation.getTime()
            
            # 记录时间步
            time_steps.append(current_time)
            
            # 计算排队长度
            queue_lengths = [traci.lane.getLastStepHaltingNumber(lane) for lane in env.approach_lane]
            avg_queue = sum(queue_lengths)/len(queue_lengths) if len(queue_lengths) > 0 else 0
            queue_history.append(avg_queue)
            
            # 更新实时图表
            line.set_xdata(time_steps)
            line.set_ydata(queue_history)
            ax.relim()
            ax.autoscale_view()
            ax.set_xlim(left=max(0, current_time-60), right=current_time+5)  # 显示最近60秒的窗口
            fig.canvas.draw()
            fig.canvas.flush_events()

            # 相位控制逻辑
            curr_phase = next_phase
            next_phase = agent.act(state=torch.FloatTensor(env.state).to(agent.device))
            
            if next_phase != curr_phase:
                # 黄灯处理
                for _ in range(3):
                    traci.trafficlight.setRedYellowGreenState(traci.trafficlight.getIDList()[0], 'rrrrrrrrrrrr')
                    traci.simulationStep()
                # 切换相位
                traci.trafficlight.setRedYellowGreenState(traci.trafficlight.getIDList()[0], env.phase[next_phase])

        # 仿真结束后保存完整图表
        plt.ioff()
        plt.figure(figsize=(12, 6))
        plt.plot(time_steps, queue_history, 'b-', linewidth=2)
        plt.xlabel('Time Step (s)', fontsize=12, fontweight='bold')
        plt.ylabel('Average Queue Length (veh)', fontsize=12, fontweight='bold')
        plt.title('Final Queue Length Analysis', fontsize=14, fontweight='bold')
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(os.path.join(path0, 'queue_analysis.png'))
        plt.show()

    except Exception as e:
        print(f"Error occurred: {str(e)}")
    finally:
        traci.close()